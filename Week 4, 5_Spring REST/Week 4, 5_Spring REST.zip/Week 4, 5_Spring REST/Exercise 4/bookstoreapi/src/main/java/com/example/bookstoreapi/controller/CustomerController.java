package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.model.Customer;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private List<Customer> customers = new ArrayList<>();
    private Long idCounter = 1L;

    // Create a new customer
    @PostMapping
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        customer.setId(idCounter++);
        customers.add(customer);
        return ResponseEntity.status(HttpStatus.CREATED).body(customer);
    }

    // Get all customers (optional, for testing)
    @GetMapping
    public ResponseEntity<List<Customer>> getAllCustomers() {
        return ResponseEntity.ok(customers);
    }
@PostMapping("/register")
public ResponseEntity<Customer> registerCustomer(
        @RequestParam("name") String name,
        @RequestParam("email") String email,
        @RequestParam("address") String address) {

    Customer customer = new Customer();
    customer.setId(idCounter++);
    customer.setName(name);
    customer.setEmail(email);
    customer.setAddress(address);

    customers.add(customer);

    return ResponseEntity.status(HttpStatus.CREATED).body(customer);
}
}
